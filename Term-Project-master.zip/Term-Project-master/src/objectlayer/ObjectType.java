package objectlayer;

public enum ObjectType {
	book,users,cart,promotion,customer,bookId,user_info,order;

}
