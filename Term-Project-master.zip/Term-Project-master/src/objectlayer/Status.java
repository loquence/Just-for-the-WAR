package objectlayer;

public enum Status {
	UNVERIFIED,VERIFIED,SUSPENDED;

}
