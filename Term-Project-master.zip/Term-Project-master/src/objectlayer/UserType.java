package objectlayer;

public enum UserType {
	CUSTOMER, ADMIN, MANAGER, SHIP;
}
