package objectlayer;

public enum OrderStatus {
	PROCESSING,SHIPPING,DELIVERED;

}
