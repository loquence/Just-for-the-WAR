# Term-Project

Team 7's CS 4050 Group project

Includes the full web page files in the cs4050TermProject folder, along with the edited server xml files which allow remote access along with mail.

Admin can edit book information

Admin can enter supplier and shipment info (name, address, phone number, contact person info (name, email, phone #)

Admin can add or delete new employees, update members

Admin can add promotions

promotions can be emailed

Browse/Search for books

Users register for system and provide info (name, phone, email, address, payment info, password)

Users must verify their email by recieving a verfication code through email

registered users can only place orders and subscribe for promotions

Users can edit their profile

Forget password facility (Use code method - send code through email to reset password)

Shopping cart linked to User (Each customer ID must be linked to one shopping cart)

Shopping cart must be able to be manipulated by user

Promotions can be added at shopping cart

Order confirmation emailed to User (email includes customer name, confirmation number, Order ID, Order Date, Shipping info, items ordered, final price of order)

Customers can view order history and track order status

System must record order info (Customer ID, order time and date, status, total price, shipping address, payment method, bill address, ordered books)

Admins and managers can pull reports (End of Day sales, low inventory notices, book sales reports, and publisher's sales report)

Shippment employee can update order status
